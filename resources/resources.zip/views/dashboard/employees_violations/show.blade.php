@extends('layouts.dashboard')
@section('content')
<!-- begin:: Content Head -->
<div class="kt-subheader   kt-grid__item" id="kt_subheader">
    <div class="kt-container  kt-container--fluid ">
        <div class="kt-subheader__main">
            <h3 class="kt-subheader__title">
                {{__('Employees Violations')}}
            </h3>
            <span class="kt-subheader__separator kt-subheader__separator--v"></span>
        </div>
        <div class="kt-subheader__toolbar">
            <a href="#" class="">
            </a>
            <a href="{{route('dashboard.employees_violations.index')}}" class="btn btn-secondary">
                {{__('Back')}}
            </a>
        </div>
    </div>
</div>
<!-- end:: Content Head -->
<!--begin::Portlet-->
<div class="kt-portlet">

    <div class="kt-portlet__body kt-portlet__body--fit">
        <div class="kt-invoice-2">
            <div class="kt-invoice__head">
                <div style="width: 80%;
                            border: solid 1px;
                            padding: 20px;
                            margin-left: auto;
                            margin-right: auto;
                            margin-bottom: 50px;
                            position: relative;
                        " class="page-content read container">

                    <img src="{{ asset('storage/companies/logos/'.$employeeViolation->employee->company->logo) }}"
                        style="margin: auto; display: table; height: 70px;" />

                    <h1 style="text-align: center;text-decoration: underline;padding: 10px; font-size: 30px">
                        {{__('Violation Letter')}}</h1>
                    <div class="details">
                        <p> <strong>{{__('Date')}} : </strong>
                            {{ \Carbon\Carbon::today()->locale(app()->getLocale())->isoFormat('LL') }}</p>
                        <p> <strong>{{__('subject')}} : </strong> {{ __('deduction of wages') }}</p>
                        <p><strong> {{__('From')}} :</strong> {{ $employeeViolation->employee->company->name_ar }}</p>
                        <p> <strong>{{__('Employee')}} : </strong>{{ $employeeViolation->employee->name() }}</p>
                        <p> <strong>{{__('Job Number')}} : </strong>{{ $employeeViolation->employee->job_number }}</p>


                        <!--<p><strong> {{__('From')}} :</strong> {{\App\Company::getHR() ? \App\Company::getHR()->name() : __('Human Resource Manager')}}</p>-->

                        @php
                        /*<p> <strong>{{__('Violation repeats')}} : </strong>{{ $employeeViolation->repeats }}</p>*/
                        @endphp
                    </div>

                    <p style="
    text-align: center;
    padding: 30px;
">
                        {{__('Below has been sent to below, instructions below have been issued to below, and the penalty agreement issued below. We hope that this hotel will reward you to avoid violating work regulations in the future.')}}
                    </p>

                    <p style="margin: 10px 0"><strong>{{__('Violation Type')}}:
                        </strong>{{ __($employeeViolation->violation->reason()) }}</p>
                    <p></p>

                    <p style="margin: 10px 0"><strong> {{__('Date')}}:
                        </strong>{{ $employeeViolation->date->locale(app()->getLocale())->isoFormat('LL') }}</p>


                    @if($employeeViolation->addition_to > 0)
                    <p style="margin: 10px 0"><strong>{{__('Violations Penalties')}}: </strong>
                        {{ __('( ' . $employeeViolation->violation->addition_to . ' ) ') . $employeeViolation->addition_to . ' '. __(' S.R')}}
                    </p>

                    @endif

                    <p style="margin: 10px 0"><strong> {{__('Addition Penalties')}}: </strong>
                        {{__($deduction)}}
                    </p>

                    @if($employeeViolation->addition_to > 0)

                    <p style="margin: 10px 0"><strong>{{__('Total Penalties')}} : </strong>
                        {{ $total_penalties }} {{ __(' S.R')}}
                    </p>
                    @endif


                    <div style="
    text-align: left;
">
                        <p>{{ $employeeViolation->employee->company->name_ar }}</p>
                        <p>{{\App\Company::getHR() ? \App\Company::getHR()->name() : ''}}</p>


                        @php
                        /*<p style="margin: 10px 0"><strong>{{__('Addition Penalties')}} : </strong>
                            {{ '( ' . __($employeeViolation->violation->addition_to) . ' ' . ($employeeViolation->absence_days ??  $employeeViolation->minutes_late) . ' ) ' . $employeeViolation->addition_to . ' '. __(' S.R')}}
                        </p>
                        <p style="margin: 10px 0"><strong>{{__('Total Penalties')}} : </strong>
                            {{ $total_penalties }} {{ __(' S.R')}}
                        </p>

                        @endif
                        <p style="text-align: center">{{__('Wish you success')}}</p>

                        <div style="text-align: left;">
                            <p>{{__('Human Resource Manager')}}</p>
                            <p>{{\App\Company::getHR() ? \App\Company::getHR()->name() : ''}}</p>*/
                            @endphp


                        </div>

                        <div style="
    text-decoration: underline;
">
                            <p>{{__('Reasons for the violation and the signature of receipt')}}:</p>
                            <p>{!! __('I ( ) acknowledge having seen the above violation penalty notice and my
                                justifications are as follows:') !!}</p>

                            <p style="width: 100%; height:8px;"></p>
                            <p style="width: 100%; height:2px; background: #333;"></p>
                            <p style="width: 100%; height:8px;"></p>
                            <p style="width: 100%; height:2px; background: #333;"></p>

                            <p>{{__('Signature')}}</p>
                            <p>{{__('Date')}}</p>
                        </div>
                    </div>
                </div>
                <div class="kt-invoice__actions">
                    <div class="kt-invoice__container">
                        <button type="button" class="btn btn-brand btn-bold"
                            onclick="window.print();">{{__('Print')}}</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--end::Portlet-->
    @endsection